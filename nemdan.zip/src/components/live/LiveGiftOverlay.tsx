import React, { useEffect, useState, useRef } from 'react';
import { Sparkles, Trophy, Flame, Crown, Star, Heart, Zap, Gift as GiftBoxIcon } from 'lucide-react';
import { LiveStreamGift } from '../../types';

interface LiveGiftOverlayProps {
  gift: LiveStreamGift | null;
  onFinished?: () => void;
}

interface QueuedGift extends LiveStreamGift {
  queueId: string;
}

export const LiveGiftOverlay: React.FC<LiveGiftOverlayProps> = ({ gift, onFinished }) => {
  const [giftQueue, setGiftQueue] = useState<QueuedGift[]>([]);
  const [currentGift, setCurrentGift] = useState<QueuedGift | null>(null);
  const [isAnimating, setIsAnimating] = useState<boolean>(false);
  const [comboStreak, setComboStreak] = useState<number>(1);
  const queueTimerRef = useRef<any>(null);
  const lastProcessedGiftRef = useRef<{ giftId: string; senderId: string; time: number } | null>(null);

  // Enqueue new gifts as they arrive
  useEffect(() => {
    if (gift) {
      const queuedItem: QueuedGift = {
        ...gift,
        queueId: `q_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
      };
      setGiftQueue(prev => [...prev, queuedItem]);
    }
  }, [gift]);

  // Process queue sequentially with accelerated timing for rapid double-tap bursts
  useEffect(() => {
    if (!isAnimating && giftQueue.length > 0) {
      const nextGift = giftQueue[0];
      const now = Date.now();

      // Check if consecutive gift from same sender (double tap streak)
      if (
        lastProcessedGiftRef.current &&
        lastProcessedGiftRef.current.giftId === nextGift.giftId &&
        lastProcessedGiftRef.current.senderId === nextGift.senderId &&
        now - lastProcessedGiftRef.current.time < 4000
      ) {
        setComboStreak(prev => prev + 1);
      } else {
        setComboStreak(nextGift.comboCount || 1);
      }

      lastProcessedGiftRef.current = {
        giftId: nextGift.giftId,
        senderId: nextGift.senderId,
        time: now
      };

      setCurrentGift(nextGift);
      setIsAnimating(true);
      setGiftQueue(prev => prev.slice(1));

      // Dynamic duration: if multiple gifts are waiting in queue (from double taps), shorten to avoid lag
      const hasBacklog = giftQueue.length > 1;
      let duration = 2800;
      if (nextGift.coinAmount >= 500) {
        duration = hasBacklog ? 3200 : 4500;
      } else if (nextGift.coinAmount >= 50) {
        duration = hasBacklog ? 2200 : 3200;
      } else {
        duration = hasBacklog ? 1400 : 2200;
      }

      if (queueTimerRef.current) clearTimeout(queueTimerRef.current);

      queueTimerRef.current = setTimeout(() => {
        setIsAnimating(false);
        setCurrentGift(null);
        if (onFinished && giftQueue.length === 0) {
          onFinished();
        }
      }, duration);
    }

    return () => {
      if (queueTimerRef.current) clearTimeout(queueTimerRef.current);
    };
  }, [giftQueue, isAnimating, onFinished]);

  if (!currentGift) return null;

  const coinAmount = currentGift.coinAmount || 1;
  const combo = Math.max(currentGift.comboCount || 1, comboStreak);
  const totalCoins = coinAmount * (currentGift.comboCount || 1);
  const isLegendary = totalCoins >= 500;
  const isBigGift = totalCoins >= 50 && !isLegendary;

  // Determine specific animation mode
  const giftNameLower = (currentGift.giftName || '').toLowerCase();
  const isRose = giftNameLower.includes('rose') || currentGift.giftIcon === '🌹';
  const isCrown = giftNameLower.includes('crown') || currentGift.giftIcon === '👑';
  const isDiamond = giftNameLower.includes('diamond') || currentGift.giftIcon === '💎';
  const isLion = giftNameLower.includes('lion') || currentGift.giftIcon === '🦁';
  const isUniverse = giftNameLower.includes('universe') || giftNameLower.includes('galaxy') || currentGift.giftIcon === '🌌';
  const isRocket = giftNameLower.includes('rocket') || currentGift.giftIcon === '🚀';
  const isFire = giftNameLower.includes('fire') || currentGift.giftIcon === '🔥';
  const isStar = giftNameLower.includes('star') || currentGift.giftIcon === '⭐';
  const isHeart = giftNameLower.includes('heart') || currentGift.giftIcon === '❤️' || currentGift.giftIcon === '💖';
  const isGiftBox = giftNameLower.includes('box') || currentGift.giftIcon === '🎁';

  return (
    <div className="absolute inset-0 pointer-events-none z-30 flex flex-col justify-between p-4 overflow-hidden select-none">
      
      {/* 1. TOP SENDER BANNER (TikTok / NEMDAN Live Pill with Combo Multiplier) */}
      <div className="flex items-center justify-between z-30 animate-slide-in-left">
        <div className={`flex items-center gap-3 px-4 py-2 rounded-full shadow-2xl backdrop-blur-xl border transition-all ${
          isLegendary 
            ? 'bg-gradient-to-r from-amber-950/95 via-yellow-900/90 to-amber-950/95 border-amber-400 text-yellow-100 ring-2 ring-yellow-400/60 shadow-amber-500/40' 
            : isBigGift 
            ? 'bg-gradient-to-r from-purple-950/95 via-pink-900/90 to-purple-950/95 border-pink-400 text-white shadow-pink-500/30'
            : 'bg-black/80 border-white/20 text-white shadow-black/50'
        }`}>
          <img
            src={currentGift.senderAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
            alt={currentGift.senderName}
            className="w-10 h-10 rounded-full object-cover border-2 border-white/70 shadow-md shrink-0"
          />
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xs tracking-tight text-amber-300 drop-shadow-xs truncate max-w-[130px]">
                {currentGift.senderName}
              </span>
              <span className="text-[10px] text-white/70 font-medium">sent</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-xs font-black text-white capitalize drop-shadow-xs truncate">
                {currentGift.giftName}
              </span>
              <span className="text-xs font-bold text-amber-300">
                (🪙 {totalCoins.toLocaleString()})
              </span>
            </div>
          </div>

          <div className="text-3xl ml-1 animate-bounce">
            {currentGift.giftIcon}
          </div>

          {/* Double Tap Combo Multiplier Badge */}
          {combo > 1 && (
            <div className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 text-white font-black text-xs shadow-lg animate-pulse ring-2 ring-white/50">
              ×{combo}
            </div>
          )}
        </div>

        {/* Queued Backlog Indicator */}
        {giftQueue.length > 0 && (
          <div className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-amber-300 font-extrabold text-[11px] flex items-center gap-1 shadow-md">
            <span>+{giftQueue.length} queued</span>
          </div>
        )}
      </div>

      {/* 2. CENTER STAGE FULL-SCREEN ANIMATED VISUALS */}
      <div className="flex-1 relative flex items-center justify-center pointer-events-none">
        
        {/* === SPECIFIC VISUAL: 🌹 ROSE === */}
        {isRose && (
          <div className="relative flex flex-col items-center justify-center animate-in zoom-in-50 duration-500">
            {/* Floating Petals Particle Field */}
            <div className="absolute inset-0 -m-32 overflow-hidden pointer-events-none">
              {[...Array(12)].map((_, i) => (
                <div
                  key={i}
                  className="absolute text-xl animate-float-down"
                  style={{
                    left: `${(i * 18 + 5) % 95}%`,
                    top: `-${Math.random() * 20}px`,
                    animationDuration: `${2 + (i % 3) * 0.8}s`,
                    animationDelay: `${i * 0.15}s`
                  }}
                >
                  🌸
                </div>
              ))}
            </div>

            {/* Central Giant Rose Visual */}
            <div className="relative">
              <div className="absolute -inset-10 bg-radial from-rose-500/40 via-pink-500/20 to-transparent rounded-full animate-ping pointer-events-none" />
              <div className="text-8xl sm:text-9xl filter drop-shadow-[0_0_35px_rgba(244,63,94,0.9)] animate-bounce">
                🌹
              </div>
            </div>

            <div className="mt-4 px-5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-rose-400 text-rose-200 font-black text-xs sm:text-sm tracking-wider uppercase shadow-2xl flex items-center gap-2">
              <span>🌹 {combo > 1 ? `${combo}× ` : ''}ROSE BOUQUET</span>
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: 👑 CROWN === */}
        {isCrown && (
          <div className="relative flex flex-col items-center justify-center animate-in slide-in-from-top-12 duration-700">
            <div className="absolute -inset-20 bg-radial from-yellow-400/40 via-amber-500/20 to-transparent rounded-full animate-pulse" />
            
            <div className="relative z-10 text-8xl sm:text-9xl filter drop-shadow-[0_0_40px_rgba(250,204,21,1)] animate-scale-bounce">
              👑
            </div>

            <div className="absolute -top-6 -right-6 text-3xl animate-spin text-yellow-300">✨</div>
            <div className="absolute -bottom-6 -left-6 text-3xl animate-spin text-amber-300">✨</div>

            <div className="mt-4 px-6 py-2 rounded-full bg-gradient-to-r from-amber-950/90 via-yellow-900/90 to-amber-950/90 backdrop-blur-md border-2 border-yellow-400 text-yellow-300 font-black text-sm sm:text-base tracking-widest uppercase shadow-2xl flex items-center gap-2">
              <Crown className="w-5 h-5 text-yellow-300 animate-pulse" />
              <span>IMPERIAL CROWN ROYALE</span>
              <Trophy className="w-5 h-5 text-amber-400" />
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: 💎 DIAMOND === */}
        {isDiamond && (
          <div className="relative flex flex-col items-center justify-center animate-in zoom-in-75 duration-500">
            <div className="absolute -inset-16 bg-radial from-cyan-400/40 via-blue-500/20 to-transparent rounded-full animate-ping" />
            
            <div className="relative text-8xl sm:text-9xl filter drop-shadow-[0_0_40px_rgba(34,211,238,0.95)] animate-bounce">
              💎
            </div>

            <div className="mt-4 px-5 py-1.5 rounded-full bg-black/85 backdrop-blur-md border border-cyan-400 text-cyan-200 font-black text-xs sm:text-sm tracking-wider uppercase shadow-2xl flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-300 animate-spin" />
              <span>SHINING SUPER DIAMOND</span>
              <Sparkles className="w-4 h-4 text-cyan-300 animate-spin" />
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: 🦁 LION ROAR === */}
        {isLion && (
          <div className="relative flex flex-col items-center justify-center animate-in zoom-in-90 duration-600">
            <div className="absolute -inset-24 bg-radial from-amber-500/50 via-yellow-600/25 to-transparent rounded-full animate-ping" />
            
            <div className="text-8xl sm:text-9xl filter drop-shadow-[0_0_45px_rgba(245,158,11,1)] animate-bounce">
              🦁
            </div>

            <div className="mt-4 px-6 py-2 rounded-full bg-black/90 backdrop-blur-lg border-2 border-amber-400 text-amber-300 font-black text-sm sm:text-base tracking-widest uppercase shadow-2xl flex items-center gap-2">
              <span>👑 ROARING GOLDEN LION</span>
              <Trophy className="w-5 h-5 text-yellow-400" />
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: 🚀 ROCKET === */}
        {isRocket && (
          <div className="relative flex flex-col items-center justify-center animate-in slide-in-from-bottom-24 duration-700">
            <div className="absolute -inset-14 bg-radial from-rose-500/40 via-orange-500/20 to-transparent rounded-full animate-pulse" />
            <div className="text-8xl sm:text-9xl filter drop-shadow-[0_0_35px_rgba(249,115,22,0.9)] animate-float-up">
              🚀
            </div>
            <div className="mt-4 px-5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-orange-400 text-orange-200 font-black text-xs sm:text-sm tracking-wider uppercase shadow-2xl">
              <span>🚀 TO THE MOON BOOST!</span>
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: 🌌 UNIVERSE / GALAXY === */}
        {isUniverse && (
          <div className="relative flex flex-col items-center justify-center animate-in zoom-in-50 duration-700">
            <div className="absolute -inset-32 bg-radial from-indigo-500/50 via-purple-600/30 to-transparent rounded-full animate-spin pointer-events-none" style={{ animationDuration: '8s' }} />
            
            <div className="text-8xl sm:text-9xl filter drop-shadow-[0_0_50px_rgba(168,85,247,1)] animate-pulse">
              🌌
            </div>

            <div className="mt-4 px-6 py-2 rounded-full bg-gradient-to-r from-purple-950/90 via-indigo-900/90 to-purple-950/90 backdrop-blur-md border-2 border-purple-400 text-purple-200 font-black text-sm sm:text-base tracking-widest uppercase shadow-2xl flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-300 animate-spin" />
              <span>UNIVERSE COSMIC PORTAL</span>
              <Sparkles className="w-5 h-5 text-purple-300 animate-spin" />
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: 🔥 FIRE === */}
        {isFire && (
          <div className="relative flex flex-col items-center justify-center animate-in zoom-in-75 duration-500">
            <div className="absolute -inset-16 bg-radial from-red-600/40 via-orange-500/20 to-transparent rounded-full animate-ping" />
            <div className="text-8xl sm:text-9xl filter drop-shadow-[0_0_35px_rgba(239,68,68,0.9)] animate-bounce">
              🔥
            </div>
            <div className="mt-4 px-5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-red-500 text-red-300 font-black text-xs sm:text-sm tracking-wider uppercase shadow-2xl flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-red-500 animate-pulse" />
              <span>SUPERCHARGED FIRE BLAST</span>
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: ⭐ STAR === */}
        {isStar && (
          <div className="relative flex flex-col items-center justify-center animate-in zoom-in-75 duration-500">
            <div className="absolute -inset-16 bg-radial from-yellow-400/40 via-amber-500/20 to-transparent rounded-full animate-pulse" />
            <div className="text-8xl sm:text-9xl filter drop-shadow-[0_0_35px_rgba(234,179,8,0.9)] animate-spin" style={{ animationDuration: '6s' }}>
              ⭐
            </div>
            <div className="mt-4 px-5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-yellow-400 text-yellow-300 font-black text-xs sm:text-sm tracking-wider uppercase shadow-2xl flex items-center gap-1.5">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span>COSMIC STAR SHOWER</span>
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: ❤️ HEART === */}
        {isHeart && (
          <div className="relative flex flex-col items-center justify-center animate-in zoom-in-75 duration-500">
            <div className="absolute -inset-16 bg-radial from-pink-500/40 via-rose-500/20 to-transparent rounded-full animate-ping" />
            <div className="text-8xl sm:text-9xl filter drop-shadow-[0_0_35px_rgba(244,63,94,0.9)] animate-bounce">
              ❤️
            </div>
            <div className="mt-4 px-5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-pink-400 text-pink-200 font-black text-xs sm:text-sm tracking-wider uppercase shadow-2xl flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-rose-400 fill-current" />
              <span>HEART BURST EXPLOSION</span>
            </div>
          </div>
        )}

        {/* === SPECIFIC VISUAL: 🎁 GIFT BOX / CUSTOM === */}
        {isGiftBox && (
          <div className="relative flex flex-col items-center justify-center animate-in zoom-in-75 duration-500">
            <div className="absolute -inset-16 bg-radial from-purple-500/40 via-pink-500/20 to-transparent rounded-full animate-pulse" />
            <div className="text-8xl sm:text-9xl filter drop-shadow-[0_0_35px_rgba(236,72,153,0.9)] animate-bounce">
              🎁
            </div>
            <div className="mt-4 px-5 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-pink-400 text-pink-200 font-black text-xs sm:text-sm tracking-wider uppercase shadow-2xl flex items-center gap-1.5">
              <GiftBoxIcon className="w-4 h-4 text-pink-400" />
              <span>MYSTERY CELEBRATION BOX</span>
            </div>
          </div>
        )}

        {/* Fallback for any other custom gift */}
        {!isRose && !isCrown && !isDiamond && !isLion && !isRocket && !isUniverse && !isFire && !isStar && !isHeart && !isGiftBox && (
          <div className="relative flex flex-col items-center justify-center animate-bounce">
            <div className="text-7xl sm:text-8xl filter drop-shadow-[0_0_30px_rgba(245,158,11,0.8)]">
              {currentGift.giftIcon}
            </div>
            <div className="mt-3 px-4 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-amber-400 text-amber-300 font-black text-xs sm:text-sm tracking-wider uppercase shadow-xl">
              {currentGift.giftName.toUpperCase()}
            </div>
          </div>
        )}

      </div>

      {/* 3. BOTTOM LIVE AUDIENCE SHOUTOUT BANNER */}
      <div className="flex justify-center z-30 animate-fade-in">
        <div className="inline-flex items-center gap-2 text-xs font-bold text-white bg-black/60 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/10 shadow-lg">
          <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
          <span>
            <strong className="text-amber-300">{currentGift.senderName}</strong> sent <strong className="text-white">{currentGift.giftName}</strong> to <strong className="text-rose-300">{currentGift.recipientName || 'Host'}</strong>!
          </span>
        </div>
      </div>

    </div>
  );
};
