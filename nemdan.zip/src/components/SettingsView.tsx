import React, { useState } from 'react';
import { 
  Settings, Shield, Lock, Smartphone, 
  Bell, Eye, Moon, Sun, Laptop, Download, 
  Trash2, CheckCircle2, User, Key, Check
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ThemeMode } from '../types';

export const SettingsView: React.FC = () => {
  const { currentUser, addToast, theme, themeMode, setThemeMode } = useApp();

  const [twoFactorEnabled, setTwoFactorEnabled] = useState(true);
  const [defaultAudience, setDefaultAudience] = useState<'public' | 'friends' | 'only_me'>('public');
  const [pushNotifs, setPushNotifs] = useState(true);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    addToast('Settings Saved', 'Your privacy and account preferences are updated.', 'success');
  };

  const themeCards: { id: ThemeMode; label: string; desc: string; icon: any }[] = [
    { id: 'light', label: 'Light', desc: 'Crisp light background', icon: Sun },
    { id: 'dark', label: 'Dark', desc: 'Eye-friendly dark theme', icon: Moon },
    { id: 'system', label: 'System', desc: 'Sync with device OS', icon: Laptop },
  ];

  return (
    <div className="max-w-4xl mx-auto px-3 sm:px-4 lg:px-6 py-6 space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs transition-colors">
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Settings className="w-7 h-7 text-blue-600 dark:text-blue-400" /> Settings & Privacy
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Manage your NEMDAN appearance, security, privacy controls, and notifications.
        </p>
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        
        {/* Appearance & Theme Section */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <Sun className="w-5 h-5 text-amber-500" /> Appearance & Theme
            </h3>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
              Active: {themeMode.toUpperCase()} ({theme})
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            Choose how NEMDAN looks to you. Select a light or dark theme, or sync automatically with your device settings.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            {themeCards.map((t) => {
              const Icon = t.icon;
              const isSelected = themeMode === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setThemeMode(t.id)}
                  className={`p-4 rounded-2xl border text-left flex flex-col justify-between gap-3 transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-blue-50/80 dark:bg-blue-950/40 border-blue-400 dark:border-blue-500 ring-2 ring-blue-500/20 shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className={`p-2.5 rounded-xl ${
                      isSelected 
                        ? 'bg-blue-600 text-white shadow-xs' 
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-2xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                    )}
                  </div>

                  <div>
                    <p className={`text-sm font-bold ${
                      isSelected ? 'text-blue-700 dark:text-blue-400' : 'text-slate-900 dark:text-white'
                    }`}>
                      {t.label}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {t.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Account & Security Section */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-600 dark:text-blue-400" /> Account Security & 2FA
          </h3>

          <div className="space-y-4 pt-1">
            <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800">
              <div className="space-y-0.5">
                <p className="text-sm font-bold text-slate-900 dark:text-white">Two-Factor Authentication (2FA)</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Require an SMS or WhatsApp OTP verification upon new device login</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setTwoFactorEnabled(!twoFactorEnabled);
                  addToast(twoFactorEnabled ? '2FA Disabled' : '2FA Enabled', '', 'info');
                }}
                className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                  twoFactorEnabled ? 'bg-blue-600 justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'
                }`}
              >
                <div className="w-4 h-4 rounded-full bg-white shadow-xs" />
              </button>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-1 text-xs">
              <p className="font-bold text-slate-900 dark:text-white">Primary Phone: {currentUser?.phone || '08142883388'}</p>
              <p className="text-slate-500 dark:text-slate-400">Registered Email: {currentUser?.email || 'danielogugu419@gmail.com'}</p>
            </div>
          </div>
        </div>

        {/* Privacy & Audience Section */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
            <Lock className="w-5 h-5 text-indigo-600 dark:text-indigo-400" /> Privacy & Feed Visibility
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Default Post Audience</label>
              <select
                value={defaultAudience}
                onChange={(e: any) => setDefaultAudience(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-800 dark:text-slate-200 outline-hidden"
              >
                <option value="public">🌍 Public (Visible to all NEMDAN members and search engines)</option>
                <option value="friends">👥 Friends Only (Visible only to confirmed friends)</option>
                <option value="only_me">🔒 Only Me (Private journal & drafts)</option>
              </select>
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800">
              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-white">Instant Messaging Receipts</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Show blue double-checks when you have read messages</p>
              </div>
              <input type="checkbox" defaultChecked className="w-4 h-4 accent-blue-600" />
            </div>
          </div>
        </div>

        {/* Notifications Section */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4 transition-colors">
          <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-purple-600 dark:text-purple-400" /> Push & In-App Notifications
          </h3>

          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div>
              <p className="text-sm font-bold text-slate-900 dark:text-white">Real-time Call & Message Alerts</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">Receive audio chime on incoming WebRTC calls</p>
            </div>
            <button
              type="button"
              onClick={() => setPushNotifs(!pushNotifs)}
              className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors cursor-pointer ${
                pushNotifs ? 'bg-blue-600 justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'
              }`}
            >
              <div className="w-4 h-4 rounded-full bg-white shadow-xs" />
            </button>
          </div>
        </div>

        <button
          type="submit"
          className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-colors cursor-pointer"
        >
          Save All Preferences
        </button>

      </form>

    </div>
  );
};

export const PWAInstallBanner: React.FC = () => {
  const [dismissed, setDismissed] = useState(false);
  const { addToast } = useApp() as any;

  if (dismissed) return null;

  const handleInstall = () => {
    addToast('PWA Ready', 'NEMDAN is ready to run offline and install on your home screen.', 'success');
    setDismissed(true);
  };

  return (
    <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-2.5 px-4 text-xs font-semibold flex items-center justify-between shadow-md">
      <div className="flex items-center gap-2">
        <Smartphone className="w-4 h-4 text-blue-200" />
        <span>Install NEMDAN App on Mobile or Desktop for Instant Push & Offline Cache</span>
      </div>
      <div className="flex items-center gap-3">
        <button
          onClick={handleInstall}
          className="bg-white text-blue-700 px-3 py-1 rounded-lg text-xs font-bold hover:bg-blue-50 transition-colors cursor-pointer"
        >
          Install PWA
        </button>
        <button onClick={() => setDismissed(true)} className="text-white/70 hover:text-white">
          ✕
        </button>
      </div>
    </div>
  );
};
