import React from 'react';
import { 
  Home, Users, Film, ShoppingBag, Users2, Flag, 
  Bookmark, Sparkles, Settings, Grid, Shield, 
  ChevronRight, CheckCircle2, Moon, Sun, ArrowUpRight,
  Wallet, Radio
} from 'lucide-react';
import { useApp, NavigationTab } from '../context/AppContext';

export const DesktopSidebar: React.FC = () => {
  const { 
    currentUser, 
    currentTab, 
    setCurrentTab, 
    setSelectedUserId,
    theme,
    toggleTheme,
    walletBalance,
    walletCurrency,
    exchangeRateNGN
  } = useApp() as any;

  const quickBal = walletCurrency === 'NGN'
    ? `₦${((walletBalance || 0) * (exchangeRateNGN || 1550)).toLocaleString('en-US', { maximumFractionDigits: 0 })}`
    : `$${(walletBalance || 0).toFixed(0)}`;

  const sidebarLinks: { id: NavigationTab; label: string; icon: any; badge?: string; color: string }[] = [
    { id: 'feed', label: 'Home Feed', icon: Home, color: 'text-blue-600 dark:text-blue-400' },
    { id: 'live', label: 'Live Broadcasts', icon: Radio, badge: 'LIVE', color: 'text-rose-600 dark:text-rose-400' },
    { id: 'wallet', label: 'NEMDAN Pay Wallet', icon: Wallet, badge: quickBal, color: 'text-blue-600 dark:text-blue-400' },
    { id: 'friends', label: 'Friends & Connections', icon: Users, badge: '2 New', color: 'text-indigo-600 dark:text-indigo-400' },
    { id: 'reels', label: 'Reels Studio', icon: Film, badge: 'Trending', color: 'text-rose-500' },
    { id: 'marketplace', label: 'Marketplace (COD)', icon: ShoppingBag, color: 'text-emerald-600 dark:text-emerald-400' },
    { id: 'groups', label: 'Groups & Clubs', icon: Users2, color: 'text-purple-600 dark:text-purple-400' },
    { id: 'pages', label: 'Verified Pages', icon: Flag, color: 'text-cyan-600 dark:text-cyan-400' },
    { id: 'saved', label: 'Saved Bookmarks', icon: Bookmark, color: 'text-teal-600 dark:text-teal-400' },
    { id: 'creator_studio', label: 'Creator Studio', icon: Sparkles, badge: 'Pro', color: 'text-amber-500' },
    { id: 'menu', label: 'All Shortcuts & Menu', icon: Grid, color: 'text-slate-600 dark:text-slate-300' },
    { id: 'settings', label: 'Settings & Privacy', icon: Settings, color: 'text-slate-600 dark:text-slate-300' },
  ];

  if (currentUser?.role === 'super_admin') {
    sidebarLinks.push({
      id: 'admin',
      label: 'Admin Control Center',
      icon: Shield,
      badge: 'Staff',
      color: 'text-rose-600'
    });
  }

  return (
    <aside className="hidden lg:block w-64 xl:w-72 shrink-0 space-y-4 sticky top-20">
      
      {/* Profile Snippet Card */}
      {currentUser && (
        <div 
          onClick={() => {
            setSelectedUserId(currentUser.id);
            setCurrentTab('profile');
          }}
          className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs hover:border-blue-300 dark:hover:border-slate-700 transition-all cursor-pointer group flex items-center justify-between"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-11 h-11 rounded-full object-cover border border-slate-200 dark:border-slate-700"
              />
              {currentUser.isVerified && (
                <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                  <CheckCircle2 className="w-2.5 h-2.5" />
                </span>
              )}
            </div>
            <div className="min-w-0">
              <p className="font-bold text-sm text-slate-900 dark:text-white truncate group-hover:text-blue-600 dark:group-hover:text-blue-400">
                {currentUser.name}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                @{currentUser.username || 'user'} • View Profile
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform shrink-0" />
        </div>
      )}

      {/* Navigation Links */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-2 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-0.5">
        {sidebarLinks.map((link) => {
          const Icon = link.icon;
          const isActive = currentTab === link.id;
          return (
            <button
              key={link.id}
              onClick={() => {
                setCurrentTab(link.id);
                setSelectedUserId(null);
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs xl:text-sm font-semibold transition-all text-left cursor-pointer ${
                isActive
                  ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <Icon className={`w-4.5 h-4.5 shrink-0 ${link.color}`} />
                <span className="truncate">{link.label}</span>
              </div>

              {link.badge && (
                <span className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded-md ${
                  link.badge === 'Pro' 
                    ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                    : link.badge === 'Trending'
                    ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}>
                  {link.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Quick Footer Links */}
      <div className="px-3 text-[11px] text-slate-400 dark:text-slate-500 space-y-1.5">
        <div className="flex flex-wrap gap-x-2 gap-y-1">
          <button onClick={() => setCurrentTab('settings')} className="hover:underline cursor-pointer">Privacy</button>
          <span>•</span>
          <button onClick={() => setCurrentTab('settings')} className="hover:underline cursor-pointer">Terms</button>
          <span>•</span>
          <button onClick={() => setCurrentTab('marketplace')} className="hover:underline cursor-pointer">Marketplace COD</button>
          <span>•</span>
          <button onClick={() => setCurrentTab('creator_studio')} className="hover:underline cursor-pointer">Creator Studio</button>
        </div>
        <p>© 2026 NEMDAN Global Network</p>
      </div>

    </aside>
  );
};
