import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, Search, Plus, Filter, 
  MapPin, CheckCircle, ShieldCheck, Tag, 
  Truck, Star, Clock, AlertCircle, X, Check
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MarketplaceItem, MarketplaceOrder } from '../types';
import { api } from '../services/api';
import { PullToRefresh } from './PullToRefresh';

const CATEGORIES = [
  'All Items',
  'Electronics',
  'Vehicles & Auto',
  'Home & Decor',
  'Fashion & Apparel',
  'Gaming & Hobbies',
  'Books & Education',
  'Crafts & Handmade'
];

export const MarketplaceView: React.FC = () => {
  const { 
    currentUser, 
    setShowCreateListing, 
    checkoutItem, 
    setCheckoutItem, 
    addToast,
    setSelectedUserId,
    setCurrentTab
  } = useApp() as any;

  const [items, setItems] = useState<MarketplaceItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All Items');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'browse' | 'my_orders' | 'my_listings'>('browse');
  const [orders, setOrders] = useState<MarketplaceOrder[]>([]);
  const [selectedItemDetail, setSelectedItemDetail] = useState<MarketplaceItem | null>(null);

  useEffect(() => {
    loadItems();
    if (currentUser) {
      api.getMarketplaceOrders(currentUser.id).then(res => setOrders(res || []));
    }
  }, [selectedCategory, currentUser]);

  const loadItems = async () => {
    const catParam = selectedCategory === 'All Items' ? undefined : selectedCategory.toLowerCase();
    const data = await api.getMarketplaceItems(catParam, searchQuery || undefined);
    setItems(data || []);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadItems();
  };

  const handlePullRefresh = async () => {
    await loadItems();
    if (currentUser) {
      const res = await api.getMarketplaceOrders(currentUser.id).catch(() => []);
      setOrders(res || []);
    }
    addToast('Marketplace Refreshed', 'Loaded latest items and listings.', 'info');
  };

  return (
    <PullToRefresh onRefresh={handlePullRefresh} label="Marketplace">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 py-4 space-y-6">
      
      {/* Top Banner & Header */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-500/20 text-green-300 border border-green-400/30 rounded-full text-xs font-bold">
            <ShieldCheck className="w-4 h-4" />
            <span>100% Cash on Delivery (COD) Protected</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">NEMDAN Marketplace</h1>
          <p className="text-sm text-slate-300">
            Buy and sell goods safely. Inspect your package first at doorstep delivery before paying cash.
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <button
            id="marketplace-create-listing-btn"
            onClick={() => setShowCreateListing(true)}
            className="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-blue-500/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Sell an Item</span>
          </button>

          <button
            onClick={() => setActiveTab(activeTab === 'my_orders' ? 'browse' : 'my_orders')}
            className="px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all cursor-pointer"
          >
            {activeTab === 'my_orders' ? 'Browse Catalog' : `My Orders (${orders.length})`}
          </button>
        </div>
      </div>

      {/* Main View Tabs */}
      {activeTab === 'browse' && (
        <div className="space-y-6">
          
          {/* Search & Category Pills */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
            <form onSubmit={handleSearchSubmit} className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products, brands, models, or cities..."
                className="w-full pl-10 pr-24 py-2.5 bg-slate-100/80 rounded-xl text-sm outline-hidden focus:bg-white border border-transparent focus:border-blue-500"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-bold"
              >
                Search
              </button>
            </form>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200/70'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Product Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {items.map(item => (
              <div
                key={item.id}
                id={`marketplace-card-${item.id}`}
                className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden hover:shadow-md transition-all duration-200 flex flex-col justify-between group"
              >
                {/* Image */}
                <div 
                  onClick={() => setSelectedItemDetail(item)}
                  className="relative h-48 sm:h-52 bg-slate-100 overflow-hidden cursor-pointer"
                >
                  <img
                    src={item.images[0]}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 left-2 bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-md">
                    {item.condition.replace('_', ' ').toUpperCase()}
                  </div>
                  <div className="absolute top-2 right-2 bg-green-950/80 backdrop-blur-md text-green-300 border border-green-500/40 text-[10px] font-extrabold px-2 py-0.5 rounded-md">
                    COD
                  </div>
                </div>

                {/* Body */}
                <div className="p-4 space-y-2 flex-1 flex flex-col justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-black text-slate-900">
                        ${item.price} <span className="text-xs font-semibold text-slate-500">{item.currency}</span>
                      </span>
                      <span className="text-[11px] text-slate-500 font-medium">📍 {item.location}</span>
                    </div>

                    <h3 
                      onClick={() => setSelectedItemDetail(item)}
                      className="font-bold text-sm text-slate-900 hover:text-blue-600 transition-colors line-clamp-1 cursor-pointer"
                    >
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  {/* Seller & Action */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <img src={item.sellerAvatar} alt={item.sellerName} className="w-6 h-6 rounded-full object-cover" />
                      <span className="text-xs text-slate-700 font-medium truncate">{item.sellerName.split(' ')[0]}</span>
                      <div className="flex items-center text-amber-500 text-[11px] font-bold">
                        <Star className="w-3 h-3 fill-amber-400" />
                        <span>{item.sellerRating}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => setCheckoutItem(item)}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
                    >
                      Order COD
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* Orders Tracking Tab */}
      {activeTab === 'my_orders' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h2 className="text-lg font-bold text-slate-900">My COD Orders & Deliveries</h2>
            <span className="text-xs text-slate-500 font-medium">{orders.length} total orders</span>
          </div>

          <div className="space-y-3">
            {orders.length > 0 ? (
              orders.map(ord => (
                <div key={ord.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-blue-600">{ord.id}</span>
                      <span className="text-[11px] bg-green-100 text-green-800 font-bold px-2 py-0.5 rounded-full capitalize">
                        Status: {ord.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-700">Delivery Address: {ord.deliveryAddress}</p>
                    <p className="text-[11px] text-slate-500">Contact: {ord.recipientPhone}</p>
                  </div>

                  <div className="text-right space-y-1">
                    <p className="text-base font-black text-slate-900">${ord.totalPrice} USD</p>
                    <p className="text-[11px] text-green-700 font-bold">Pay Cash Upon Delivery</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-slate-400">
                <p className="text-sm">No active orders yet.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Product Detail Dialog */}
      {selectedItemDetail && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedItemDetail(null)}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 z-10"
            >
              <X className="w-5 h-5" />
            </button>

            <img
              src={selectedItemDetail.images[0]}
              alt={selectedItemDetail.title}
              className="w-full h-64 object-cover"
            />

            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-slate-900">{selectedItemDetail.title}</h3>
                  <p className="text-sm text-slate-500 font-medium">📍 {selectedItemDetail.location}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-black text-blue-600">${selectedItemDetail.price} {selectedItemDetail.currency}</p>
                  <span className="text-[10px] bg-green-100 text-green-800 font-bold px-2 py-0.5 rounded-full">
                    Cash on Delivery
                  </span>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-700 leading-relaxed border border-slate-200">
                {selectedItemDetail.description}
              </div>

              <div className="flex items-center justify-between p-3 bg-blue-50/60 rounded-xl border border-blue-200 text-xs">
                <div className="flex items-center gap-2">
                  <img src={selectedItemDetail.sellerAvatar} alt={selectedItemDetail.sellerName} className="w-8 h-8 rounded-full object-cover" />
                  <div>
                    <p className="font-bold text-slate-900">{selectedItemDetail.sellerName}</p>
                    <p className="text-[11px] text-slate-500">Seller Rating: ★ {selectedItemDetail.sellerRating}</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setSelectedItemDetail(null);
                    setCurrentTab('messages');
                  }}
                  className="text-xs font-bold text-blue-600 hover:underline"
                >
                  Message Seller
                </button>
              </div>

              <button
                onClick={() => {
                  setCheckoutItem(selectedItemDetail);
                  setSelectedItemDetail(null);
                }}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md transition-colors cursor-pointer"
              >
                Place Cash on Delivery Order
              </button>
            </div>
          </div>
        </div>
      )}

      </div>
    </PullToRefresh>
  );
};

export const CreateListingModal: React.FC = () => {
  const { 
    currentUser, 
    showCreateListing, 
    setShowCreateListing, 
    addToast 
  } = useApp() as any;

  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('electronics');
  const [condition, setCondition] = useState('like_new');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [location, setLocation] = useState('Berlin, Germany');
  const [loading, setLoading] = useState(false);

  if (!showCreateListing) return null;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);
    try {
      await api.createMarketplaceItem({
        title,
        price: parseFloat(price) || 50,
        currency: 'USD',
        category,
        condition,
        description,
        images: [imageUrl || 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=600&auto=format&fit=crop&q=80'],
        location,
        sellerId: currentUser.id,
        sellerName: currentUser.name,
        sellerAvatar: currentUser.avatar,
        sellerRating: 5.0,
        deliveryMethod: 'Cash on Delivery'
      });
      setShowCreateListing(false);
      addToast('Listing Created!', 'Your item is live on the NEMDAN Marketplace.', 'success');
    } catch (err: any) {
      addToast('Listing Error', err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden relative">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-base text-slate-900">Sell an Item (COD)</h3>
          <button onClick={() => setShowCreateListing(false)} className="p-1 text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleCreate} className="p-5 space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Item Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Sony Alpha A7 III Camera Body"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:bg-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Price (USD)</label>
              <input
                type="number"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="150.00"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 outline-hidden capitalize"
              >
                <option value="electronics">Electronics</option>
                <option value="fashion">Fashion</option>
                <option value="home">Home & Decor</option>
                <option value="vehicles">Vehicles</option>
                <option value="gaming">Gaming</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Condition</label>
            <select
              value={condition}
              onChange={(e) => setCondition(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 outline-hidden capitalize"
            >
              <option value="new">Brand New (In Box)</option>
              <option value="like_new">Like New (Mint)</option>
              <option value="good">Good (Normal Use)</option>
              <option value="fair">Fair (Visible Wear)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Image URL</label>
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://images.unsplash.com/..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">City / Location</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Amsterdam, Netherlands"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Include condition details, reasons for selling, and meetup preferences..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:bg-white resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm shadow-md transition-colors cursor-pointer"
          >
            {loading ? 'Publishing Listing...' : 'Publish Listing (COD)'}
          </button>
        </form>
      </div>
    </div>
  );
};

export const CheckoutOrderModal: React.FC = () => {
  const { 
    currentUser, 
    checkoutItem, 
    setCheckoutItem, 
    addToast 
  } = useApp() as any;

  const [address, setAddress] = useState('742 Evergreen Terrace, Sector 4');
  const [phone, setPhone] = useState('+1 (555) 389-1049');
  const [instructions, setInstructions] = useState('Leave with concierge or call upon arrival');
  const [loading, setLoading] = useState(false);

  if (!checkoutItem) return null;

  const handleOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      addToast('Sign in required', 'Please log in to place an order.', 'warning');
      return;
    }
    setLoading(true);
    try {
      await api.orderMarketplaceItem({
        itemId: checkoutItem.id,
        buyerId: currentUser.id,
        sellerId: checkoutItem.sellerId,
        totalPrice: checkoutItem.price,
        deliveryAddress: address,
        recipientPhone: phone,
        deliveryInstructions: instructions
      });
      setCheckoutItem(null);
      addToast('Order Placed Successfully!', 'Your COD order is confirmed. Prepare exact cash upon doorstep arrival.', 'success');
    } catch (err: any) {
      addToast('Order Error', err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden relative">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-base text-slate-900">Cash on Delivery Checkout</h3>
            <span className="text-[10px] bg-green-100 text-green-800 font-bold px-2 py-0.5 rounded-full">
              No Advance Payment
            </span>
          </div>
          <button onClick={() => setCheckoutItem(null)} className="p-1 text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleOrder} className="p-5 space-y-4">
          {/* Item summary */}
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center gap-3">
            <img src={checkoutItem.images[0]} alt={checkoutItem.title} className="w-14 h-14 rounded-xl object-cover" />
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold text-slate-900 truncate">{checkoutItem.title}</h4>
              <p className="text-xs text-blue-600 font-extrabold">${checkoutItem.price} {checkoutItem.currency}</p>
              <p className="text-[10px] text-slate-500">Seller: {checkoutItem.sellerName}</p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Delivery Street Address</label>
            <input
              type="text"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Recipient Phone for Courier</label>
            <input
              type="tel"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Delivery Notes</label>
            <input
              type="text"
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-hidden focus:bg-white"
            />
          </div>

          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1">
            <p className="font-bold flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5 text-amber-600" /> COD Safety Notice:
            </p>
            <p className="text-[11px] text-amber-800">
              Courier will allow you to inspect the physical item before collecting cash. Keep exact change ready.
            </p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-sm shadow-md transition-colors cursor-pointer"
          >
            {loading ? 'Confirming Order...' : `Confirm Order — Pay $${checkoutItem.price} upon Delivery`}
          </button>
        </form>
      </div>
    </div>
  );
};
